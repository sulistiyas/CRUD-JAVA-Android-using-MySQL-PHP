<?php

define('HOST', 'localhost');
define('USER', 'inls3676_retrofit');
define('PASS', '-weatherstrom');
define('DB', 'inls3676_test_crud');

$con = mysqli_connect(HOST, USER, PASS, DB) or die('Unable to Connect');
